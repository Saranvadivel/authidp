const passport = require("passport");
const { Issuer, Strategy } = require("openid-client");
const TokenModel = require("../../schema/tokenmodel");

Issuer.discover(process.env.IDP_URL)
  .then((oidcIssuer) => {
    console.log("IDP Issuer discovered");

    const client = new oidcIssuer.Client({
      client_id: process.env.CLIENT_ID, // Fixed spelling: client_Id -> client_id
      client_secret: process.env.CLIENT_SECRET, // Fixed client_scret -> client_secret
      response_types: ["code"],
      redirect_uris: process.env.REDIRECT_URIS.split(","), // Ensure redirect URIs are comma-separated
    });

    passport.use(
      "oidc",
      new Strategy(
        { client, passReqToCallback: true },
        async (req, tokenSet, userinfo, done) => {
          if (tokenSet && userinfo) {
            const data = {
              auth_token: tokenSet.access_token, // Use lower case for keys
              hash: userinfo.sub, // Usually sub is used for user identifier
            };

            try {
              await TokenModel.create({
                hash: userinfo.sub, // Use sub for consistency
                access_token: tokenSet.access_token,
                refresh_token: tokenSet.refresh_token,
                expireTime: tokenSet.expires_at,
                jwt: tokenSet.id_token,
              });

              return done(null, data);
            } catch (error) {
              return done(error);
            }
          } else {
            return done("Authentication error", false);
          }
        }
      )
    );
  })
  .catch((err) => {
    console.error("OIDC Issuer discovery error", err);
  });

passport.serializeUser((user, done) => {
  console.log("Serializing user");
  done(null, user);
});

passport.deserializeUser((user, done) => {
  console.log("Deserializing user");
  done(null, user);
});
