const axios = require("axios");

// Middleware for Authorization
const Auth = async (req, res, next) => {
  try {
    const token = req?.headers?.authorization; // Fixed the token extraction
    console.log("Token:", token);

    if (token && token.split(" ")[0] === "Bearer") {
      const scope = req.scope;
      const Token = token.split(" ")[1]; // Extract token part after Bearer

      const response = await axios.get(`${process.env.IDP_SERVER}/account/me`, {
        headers: { Authorization: `Bearer ${Token}` }, // Fix Authorization header typo
      });

      const scopes = response?.data?.scopes;
      if (scopes.includes(`${scope}`)) {
        req.actualScope = scopes; // Fixed: check -> scopes
        req.hash = response.data.hash;
        next(); // Proceed to the next middleware
      } else {
        res.status(403).send("Insufficient scope");
      }
    } else {
      res.status(401).send("Invalid token");
    }
  } catch (error) {
    console.error("Error in authentication:", error);
    res.status(500).send("Internal Server Error");
  }
};

module.exports = Auth;
