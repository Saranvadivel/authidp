const express = require("express");
require("dotenv").config();
const session = require("express-session");
const cors = require("cors");
const helmet = require("helmet");
const passport = require("passport");
const IdpRoutes = require("./router/idp_route");
require("./auth/passportconfig/passport")
const app = express();
app.use(
  cors({
    origin: "http://localhost:3000", // Correct the origin
    credentials: true, // Fixed typo: "Credentails" -> "credentials"
    allowedHeaders: ["Content-Type", "Authorization"], // Fixed "Contenet-Type"
  })
);


app.use(helmet());

app.use(
  session({
    secret: process.env.COOKIE_SECRET, 
    resave: true,
    saveUninitialized: true,
    cookie: { secure: true }, 
  })
);

// Passport initialization
app.use(passport.initialize());
app.use(passport.session());

// Use routes
app.use("/api", IdpRoutes); // Mount IDP routes

const PORT = process.env.PORT;
const server=app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
server.on("request",(req,res)=>{
    console.log(req.method,"------------------>",req.originalUrl);
    
})
