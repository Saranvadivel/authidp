const express = require("express");
const passport = require("passport");
// const passport = require("passport");
const IdpRoutes = express.Router();

// Route for the homepage
IdpRoutes.get("/", (req, res) => {
  console.log("Enter home log...");
  res.send('<a href="/api/login">Auth provider</a>');
});

// Login route with OIDC authentication
IdpRoutes.get(
  "/login",
  passport.authenticate("oidc", {
    scope: "openid", // Fixed spelling and scope array
  })
);

// Login verify route
IdpRoutes.post(
  "/login/verify",
  passport.authenticate("oidc"), // Authenticate with OIDC
  (req, res) => {
    return res.status(200).json({ token: req.user.auth_token, code: 200 });
  }
);

module.exports = IdpRoutes;







