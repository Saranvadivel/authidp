const mongoose=require("mongoose")
const dburl=()=>{
    let db=mongoose.createConnection(process.env.DB_URL)
    return db
}

module.exports=dburl()