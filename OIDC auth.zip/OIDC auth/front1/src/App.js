// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import UserInfo from './userinfo';


const App = () => {
  const handleLogin = () => {
    // Redirect to your Node.js login route
    // window.location.href = 'http://192.168.29.151:3000/api/login'; 
    window.open('http://192.168.29.151:5000/api/login',"_self")
  };

  return (
    <Router>
      <div>
        <nav>| 
          <Link to="/user">User Info</Link>
        </nav>
        <Routes>
          <Route path="/" element={
            <div>
              {/* <h1>Welcome to the Auth App</h1> */}
              <button onClick={(e)=>{console.log(e);
              handleLogin()
              }}>Log In with OAuth 2.0 Provider</button>
            </div>
          } />
          <Route path="/user" element={<UserInfo />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
